This is a small development build of the Mod Menu for the first Public Full Game Demo.
I never fully finished this version, so some stuff might not work as expected.