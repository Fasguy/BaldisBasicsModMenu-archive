##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###                (AKA. BALDI'S BASICS CLASSIC REMASTERED)                ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                    (http://basically-games.itch.io)                    ###
##############################################################################
##############################################################################

Baldi's Basics Classic Remastered ModMenu v1.0.1 by Fasguy
Compatible Game Version: v1.1

INFO:
IF YOU WANT TO USE THE MOD, THEN YOU NEED TO HAVE THE ORIGINAL GAME ALREADY INSTALLED.

############################### HOW TO INSTALL ###############################
Video Tutorial: https://youtu.be/vAZmy1_ktlk
1. Download and Install BepInEx 5 (https://docs.bepinex.dev/articles/user_guide/installation/index.html)
2. Go into the "BepInEx" folder.
3. Go into the "plugins" folder.
4. Put the entire "ModMenu" folder into the "plugins" folder.
5. Start the game.
6. Press TAB in-game to open the ModMenu.


################################# HOW TO USE #################################
TAB:				Open/Close ModMenu


################################# CHANGELOG ##################################
v1.0.1 (Game v1.1)
* Audio Vomit now works even when the in-game launcher is disabled
* Mrs. Pomp can properly play her "Zero" audio again
* Entering one of Chalkles' rooms while it's disabled no longer causes the room to lock anyways
* Null is no longer affected by Baldi's slap speed randomizer setting
* The game no longer softlocks, when opening the ModMenu during a Menu->Game or YCTP->Game transition
* Fixed an issue that caused Null projectiles to be tethered to the player camera's rotation

------------------------------------------------------------------------------

v1.0.0 (Game v1.1)
* Initial release