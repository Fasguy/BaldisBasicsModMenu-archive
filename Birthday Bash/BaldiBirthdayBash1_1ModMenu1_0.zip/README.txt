##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###                   (AKA. BALDI'S BASICS BIRTHDAY BASH)                  ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                       (http://mystman12.itch.io)                       ###
##############################################################################
##############################################################################

Baldi's Basics Birthday Bash Mod Menu v1.0 by Fasguy
Compatible Game Version: v1.0

################################# HOW TO USE #################################
### WINDOWS ###:
Windows Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to [Game Name]_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).

### macOS/OS X ###:
macOS/OS X Video Tutorial: https://youtu.be/42aZEcvqHc8?t=3m20s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Copy the "Assembly-CSharp.dll" file.
2. Find your existing installation of the game.
3. Right-Click (or Control-Click) on the game (usually called BALDI).
4. Click "Show Package Contents".
5. Go to Contents -> Resources -> Data -> Managed
6. Paste the "Assembly-CSharp.dll" file into this Folder.
7. Replace the already existing file.
8. Start the game by Right-Clicking (or Control-Clicking) on the game and choosing "Open".
9. Press TAB in-game (to open the Mod Menu).

### LINUX ###:
Linux Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5m35s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to [Game Name]_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).


################################## CONTROLS ##################################
Mouse:				Viewpoint Movement
Left Click:			Use Door
Right Click:			Use Item
WASD or Up/Down/Left/Right:	Move
Alt + F4:			Close Game
TAB:				Open/Close Mod Menu


################################# CHANGELOG ##################################
v1.0 (Game v1.0)
~ This version is on par with v1.12.1 of the Baldi's Basics in Education and Learning Mod Menu