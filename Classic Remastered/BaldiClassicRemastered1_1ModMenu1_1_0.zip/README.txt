##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###                (AKA. BALDI'S BASICS CLASSIC REMASTERED)                ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                    (http://basically-games.itch.io)                    ###
##############################################################################
##############################################################################

Baldi's Basics Classic Remastered ModMenu v1.1.0 by Fasguy
Compatible Game Version: v1.1

INFO:
IF YOU WANT TO USE THE MOD, THEN YOU NEED TO HAVE THE ORIGINAL GAME ALREADY INSTALLED.

############################### HOW TO INSTALL ###############################
Video Tutorial: https://youtu.be/vAZmy1_ktlk
1. Download and Install BepInEx 5 (https://docs.bepinex.dev/articles/user_guide/installation/index.html)
2. Go into the "BepInEx" folder.
3. Go into the "plugins" folder.
4. Put the entire "ModMenu" folder into the "plugins" folder.
5. Start the game.
6. Press TAB in-game to open the ModMenu.


################################# HOW TO USE #################################
TAB:				Open/Close ModMenu


################################# CHANGELOG ##################################
v1.1.0 (Game v1.1)
+ The ModMenu now has a starting page, which shows some general information about the ModMenu.
+ "Vanilla" and "Classic, Yet Again" now have individual plugin icons.
+ The reference resolution of the ModMenu can now be controlled through the settings.
+ Added new option that allows the game's Fun Settings to work while playing Endless mode.
+ Added new option that allows the game's Fun Settings to work while playing Null/Glitch style.
+ The Fun Setting "Mirrored" can now be toggled directly through the ModMenu.
+ The Fun Setting "Lights Out" can now be toggled directly through the ModMenu.
+ The Fun Setting "Hard Mode" can now be toggled directly through the ModMenu.
+ The Fun Setting "Free Run" can now be toggled directly through the ModMenu.
+ Lethal touch can now be enabled for Beans' gum wad.
+ Baldi's appraisal time can now be changed through the ModMenu.
+ ModMenu values can now be reset to default, wherever a default value exists.
* Setting a custom jump amount for Playtime now requires enabling "Override Jumprope values".
* Switching from Null/Glitch style to another scene no longer breaks the "Quit" button in the pause menu.
* Null no longer tries to make lights flicker, while the "Lights out" Fun setting is enabled.
* Highscores can no longer be saved, while the ModMenu is installed.
* FourtyTwo balloons no longer break in hard mode.
* Fliparoo doesn't potentially invert the horizontal mouse movement anymore, when loading a preset.
* Sprites no longer cull too early, when manipulating the camera fov.
* Switching to a Free Run scene will now automatically enable the "Free Run" Fun Setting.
* Fixed some general issues with loading presets from the main menu.
* The character modifier "Enabled" can now changed through the bulk editor.
* The bulk editor menu now gets properly updated when values change.

------------------------------------------------------------------------------

v1.0.1 (Game v1.1)
* Audio Vomit now works even when the in-game launcher is disabled.
* Mrs. Pomp can properly play her "Zero" audio again.
* Entering one of Chalkles' rooms while it's disabled no longer causes the room to lock anyways.
* Null is no longer affected by Baldi's slap speed randomizer setting.
* The game no longer softlocks, when opening the ModMenu during a Menu->Game or YCTP->Game transition.
* Fixed an issue that caused Null projectiles to be tethered to the player camera's rotation.
* The default "Character activation distance" value has been lowered from 10 to 5.

------------------------------------------------------------------------------

v1.0.0 (Game v1.1)
* Initial release.