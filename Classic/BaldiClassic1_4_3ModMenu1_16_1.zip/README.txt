##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###             (AKA. BALDI'S BASICS IN EDUCATION AND LEARNING)            ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                       (http://mystman12.itch.io)                       ###
##############################################################################
##############################################################################

Baldi's Basics in Education and Learning Mod Menu v1.16.1 by Fasguy
Compatible Game Version: v1.4.3

INFO: IF YOU WANT TO USE THE MOD, THEN YOU NEED TO HAVE THE ORIGINAL GAME ALREADY INSTALLED.

############################### HOW TO INSTALL ###############################
### WINDOWS ###:
Windows Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5s
1. Find your existing installation of the game.
2. Go to [Game Name]_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).

### macOS/OS X ###:
macOS/OS X Video Tutorial: https://youtu.be/42aZEcvqHc8?t=3m20s
1. Copy the "Assembly-CSharp.dll" file.
2. Find your existing installation of the game.
3. Right-Click (or Control-Click) on the game (usually called BALDI).
4. Click "Show Package Contents".
5. Go to Contents -> Resources -> Data -> Managed
6. Paste the "Assembly-CSharp.dll" file into this Folder.
7. Replace the already existing file.
8. Start the game by Right-Clicking (or Control-Clicking) on the game and choosing "Open".
9. Press TAB in-game (to open the Mod Menu).

### LINUX ###:
Linux Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5m35s
1. Find your existing installation of the game.
2. Go to [Game Name]_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).


################################# HOW TO USE #################################
TAB:					Open/Close Mod Menu
CTRL+Backspace			Open/Close Problem Trace Console


################################# CHANGELOG ##################################
v1.16.1 (Game v1.4.3)
~ The 3D-Camera has been rewritten entirely. Hopefully the weird turning glitch is now fixed.
* "It's a Bully" now moves when enabling "Extended Bully" gets enabled while "It's a Bully" is already active.
* "It's a Bully" doesn't say his "No items?" line anymore, when on cooldown during "Extended Bully"
* Fixed a bug, that caused "Character ignores Player" to not work.
* "It's a Bully" can no longer be pushed by BSODA, when "Extended Bully" is disabled.
* "It's a Bully" no longer gets stuck in the ground when activating.
* The "Additional Options" menu no longer gets stuck, while being inside an added camera.

------------------------------------------------------------------------------

v1.16 (Game v1.4.3)
+ Added "Google's Basics" to the Trippy Mode Menu.
+ Added a "Lethal Touch" modifier to all characters.
+ Added the "Mirror Mode" gameplay modifier.
+ Added the "Extended Bully" gameplay modifier.
* The "Character Speed" modifier on "It's a Bully" now actually does something, when enabling "Extended Bully".
* Clones created during Stormy Night Mode now actually get affected by Stormy Night Mode.

------------------------------------------------------------------------------

v1.15 (Game v1.4.3)
+ Added a "Character Laziness" modifier. Characters can still interact with you, but they won't target you directly.
+ Added a "Jealousy Modifier" to Arts and Crafters, that changes how many Notebooks you need for him to get angry.
+ Added a "Player Height" modifier. Just in case you want to be a giraffe.
+ Added the "Gameplay Modifiers" menu.
+ Added a "Boots Timer" modifier to the Big ol' Boots.
+ Added "Stormy Night" Mode.
+ Added "Slender Tutor" Mode.
+ Added a "Moves when being loked at" Modifier to Tutor Baldi
- Removed "Joomp".
* Replaced Playtime's "10 Jumps Modifier" with a custom number input.
* Replaced "Final-Mode Red Tint" with a color selection menu.
* Renamed "Character-position randomizer" to "Randomize Character Positions".
* Renamed "Item-position randomizer" to "Randomize Item Positions".
* Moved "Randomize Character Positions" to the "Teleporter" menu.
* Moved "Randomize Item Positions" to the "Teleporter" menu.
* Moved "Jump anywhere" to the "Player Modifier" menu.
* Adjusted the 3D Camera to work with the Fliparoo modifier.
* Fixed a bug, that caused the "Player Movement Speed" value to disappear when changing "Camera FOV".
* Fixed a bug, that caused the Big ol' Boots to not work.
* Fixed a bug, that caused the mouse sensitivity to be slower than it should be.
* Fixed an oversight, that caused the Problem Trace Console to not appear on the Warning Screen.
* Typo fixes.

------------------------------------------------------------------------------

v1.14 (Game v1.4.3)
+ Added a "Jump anywhere" modifier.
* Turning Fliparoo on and back off again doesn't turn you into a midget anymore.
* "Entity GPS" is no longer affected by the "Video Diarrhea" modifier.
* The "Problem Trace Console" is now fully separated from the Mod Menu itself.
* Adjusted UI to prevent problems when 2 buttons overlap.
* Cameras created in the Camera Menu now actually respond to the 3D-Camera again.
* Fixed a bug, that caused the Mod Menu to get stuck in the Test Room.
* Player Speed and Noclip can now be used in the TestRoom scene.
* (Android Version) Fixed a bug, that caused 1st Prize's sounds to not be played.

------------------------------------------------------------------------------

v1.13 (Game v1.4.1)
~ The old "Help System" has been replaced by a new "Information System"
+ Added the Trippy-Mode menu (Use at your own risk!)
+ Added the "Problem Trace Console" [Press CTRL+Backspace to open it] (If you encounter bugs, please open it and check if some errors have appeared and report them to me)
+ Added the Ceiling-Walker (Fliparoo) modifier.
+ Added an Item-position randomizer.
+ Added a Baldi slap-speed multiplier. (Because people won't stop asking about it)
+ 1st Prize's removed "Turning-Speed Slowdown" modifier has been reworked into the "Turning Speed Multiplier".
* Fixed the FPS display.
* Fixed "Randomly switch character positions". Now it should actually switch positions, instead of hoarding them all in one place.
* 1st-Prize now appears correctly in added cameras again.
* Submenu buttons now actually show all 3 ellipsis again.

------------------------------------------------------------------------------

v1.12.1 (Game v1.4.1)
* Hopefully fixed a bug, that caused the game to "lock up" at the very beginning.
* The Disorienting Tape now actually only plays for the amount set in the value editor and re-opens afterwards.
* Fixed the BSODA modifiers not having any effect.
* Fixed First-Prize's speed modifier.
* Fixed the 3D-Camera Movement preventing the cursor from moving in the notebooks and pause menu.

------------------------------------------------------------------------------

v1.12 (Game v1.4.1)
+ Added a modifier, that allows you to turn on the final red tint at will.
+ Re-Introducing the 3D-Camera.
* Adjusted Noclip to work with new 3D-Camera system.
* Custom detention times will stop the Principal from announcing how long you have detention.
* Fixed a bug, that caused custom detention times to not work correctly.
* Fixed a bug, that teleported you to the real First Prize, when being pushed by a clone.
* Fixed a bug, that caused clones of Gotta Sweep to sweep you in seemingly random directions.
* Fixed a bug, that prevented It's a Bully from ignoring you.
* Fixed a bug, that prevented It's a Bully's Cooldown-modifier from working.

------------------------------------------------------------------------------

v1.11.1 (Game v1.4.1)
* Compatibility for Game v1.4.1

------------------------------------------------------------------------------

v1.11 (Game v1.4)
+ Added an option to disable the HUD.
+ Added an option to show FPS.
+ Added an option to change the Player's FOV.
- Removed 3D Camera-Movement.
- Removed 1st Prize's "Turning-Speed Slowdown" modifier.
* Fixed a bug, that caused the Exit Teleporter to teleport the exits to you and not the other way around.
* Fixed a bug, that caused the last active distance to remain on a character's GPS name.
* Fixed a bug, that caused the game to seemingly freeze when caught by Baldi inside the Mod Menu.
* The current Help-System will slowly be phased out for a more efficient system.

------------------------------------------------------------------------------

v1.10.1 (Game v1.3.2)
* Fixed a bug, that caused some scenes to never progress when using the Scene Manager.

------------------------------------------------------------------------------

v1.10 (Game v1.3.2)
~ The Core Library has been rewritten.
+ Added an option to randomly switch character positions.
+ Added a scene manager.
+ Detention-Time can now be set manually.
* A lot of general code optimizations.
* All values now reset when a new round has been started.
* The default entity teleport-direction has been switched (You -> Entity).
* Fixed a bug, that prevented cameras from activating, after removing the currently active one.
* Fixed a bug, that caused the player to start levitating when pushing against furniture.
* Fixed a bug, that caused the exits to shift upwards after getting all questions right.
* Fixed a bug, that caused 1st Prize to not be shown properly on added cameras.

------------------------------------------------------------------------------

v1.9.1 (Game v1.3.2)
* Fixed a bug that caused the 3D-Camera to wrap vertically.

------------------------------------------------------------------------------

v1.9 (Game v1.3.2)
+ Added a visibility modifier for characters.
+ Added a way to add cameras anywhere in the game (this will be part of a bigger project).
+ Added a way to change your maximum Stamina value.
* Noclip now allows you to fly up and down, when the 3D-Camera is activated.
* Entities can now see and interact with you, if noclip is activated and their behaviour isn't disabled.
* The mod is now more suitable for lower and higher resolutions.
* Fixed some broken help texts.

------------------------------------------------------------------------------

v1.8 (Game v1.3.2)
~ Menu UI has been revised again to make it more future proof (sorry).
+ Added help-buttons.
+ Added character-specific options.
+ Added a character-size modifier.
- The "Set" button on value editors has been removed.
* Notebooks now don't get ticked anymore, when collecting them in the endless mode.
* Collected notebooks now show their collected state properly.
* Fixed a bug, that caused Playtime to keep moving at her current speed after changing it.
* Fixed a bug, that caused the entity GPS to not work properly on clones.
* Fixed a bug, that caused the Character Distance Meter to stop working after deleting clones.

------------------------------------------------------------------------------

v1.7.1 (Game v1.3.2)
* Character-Speed values now actually reset when starting a new round.

------------------------------------------------------------------------------

v1.7 (Game v1.3.2)
+ Added a Character Distance Meter.
+ Added an Item Value Editor.
* Closing and re-opening a sub-menu will now display the starting page of that sub-menu.
* The player speed modifier now also applies to the player's walking speed.
* Clones now have a gps name as well.
* Disabling a character now disables this character's clones as well.
* Fixed a bug, that caused clones to not be deletable.

------------------------------------------------------------------------------

v1.6.1 (Game v1.3.2)
* Fixed a bug, that caused the entity gps to always be visible.

------------------------------------------------------------------------------

v1.6 (Game v1.3.2)
~ Introduction of a new menu-ui-system.
+ Added an exit-teleporter.
+ Added a character-speed modifier.
+ Added a character disabler/remover.
* Cloned characters can now be removed.
* The code has been optimized.
* The Mod Menu now shows each character's full name.

------------------------------------------------------------------------------

v1.5 (Game v1.3.2)
+ Added a character cloner.
+ Added the ability to never run out of items.
+ Added a running-speed multiplier.
* Renamed the "Item Manipulator" to "Item Cheater".
* Fixed a bug, that caused the Mod Menu to break the game every second start.

------------------------------------------------------------------------------

v1.4 (Game v1.3.2)
* Adjusted the teleporter for the ability to teleport each character to you.
* Adjusted the notebook-teleporter for the ability to teleport each notebook to you.

------------------------------------------------------------------------------

v1.3.1 (Game v1.3.2)
* Fixed a memory leak caused by the new UI

------------------------------------------------------------------------------

v1.3 (Game v1.3.2)
+ Added the ability to teleport to each character.
+ Added the ability to teleport to each notebook.
* Optimized the code used for the gps character names.
* Fixed an oversight, that caused the bully's gps text to appear in his belly.
* UI has been "re-designed".

------------------------------------------------------------------------------

v1.2 (Game v1.3.2)
+ Added the ability to manipulate your entire inventory.
* Fixed a bug, that caused the pause menu to not actually pause the game.

------------------------------------------------------------------------------

v1.1 (Game v1.3.1)
+ Added the ability to be ignored by 1st-Prize.
+ Added the ability to phase through solid matter.
* Fixed a bug, that allowed you to go through objects by using your new neck.
* Fixed a bug, that caused some NPCs to scream for no reason.
* Fixed a bug, that caused Gotta-Sweep to be overly attached.

------------------------------------------------------------------------------

v1.0 (Game v1.2.2)
+ Added the ability to be ignored by Baldi.
+ Added the ability to be ignored by the Bully.
+ Added the ability to be ignored by Playtime.
+ Added the ability to be ignored by Crafters.
+ Added the ability to be ignored by Gotta-Sweep.
+ Added the ability to be ignored by the Principal.
+ Added the answer to life the universe and everything.
+ Added a neck to the player for up and down head-movement.
+ Added the ability to run forever.
+ Added a GPS-system.