##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###             (AKA. BALDI'S BASICS IN EDUCATION AND LEARNING)            ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                       (http://mystman12.itch.io)                       ###
##############################################################################
##############################################################################

Fasguy's Mod Menu v1.8 for Baldi's Basics in Education and Learning v1.3.2


################################# HOW TO USE #################################
### WINDOWS ###:
Windows Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to BALDI_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).

### macOS/OS X ###:
macOS/OS X Video Tutorial: https://youtu.be/42aZEcvqHc8?t=3m20s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Copy the "Assembly-CSharp.dll" file.
2. Find your existing installation of the game.
3. Right-Click (or Control-Click) on the game (usually called BALDI).
4. Click "Show Package Contents".
5. Go to Contents -> Resources -> Data -> Managed
6. Paste the "Assembly-CSharp.dll" file into this Folder.
7. Replace the already existing file.
8. Start the game by Right-Clicking (or Control-Clicking) on the game and choosing "Open".
9. Press TAB in-game (to open the Mod Menu).

### LINUX ###:
Linux Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5m35s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to BALDI_Data -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).


################################## CONTROLS ##################################
Mouse:				Viewpoint Movement
Left Click:			Use Door
Right Click:			Use Item
WASD or Up/Down/Left/Right:	Move
Alt + F4:			Close Game
TAB:				Open/Close Mod Menu


################################# CHANGELOG ##################################
v1.8 (Game v1.3.2)
~ Menu UI has been revised again to make it more future proof (sorry).
+ Added help-buttons.
+ Added character-specific options.
+ Added a character-size modifier.
* The "Set" button on value editors has been removed.
* Notebooks now don't get ticked anymore, when collecting them in the endless mode.
* Collected notebooks now show their collected state properly.
* Fixed a bug, that caused Playtime to keep moving at her current speed after changing it.
* Fixed a bug, that caused the entity GPS to not work properly on clones.
* Fixed a bug, that caused the Character Distance Meter to stop working after deleting clones.

------------------------------------------------------------------------------

v1.7.1 (Game v1.3.2)
* Character-Speed values now actually reset when starting a new round.

------------------------------------------------------------------------------

v1.7 (Game v1.3.2)
+ Added a Character Distance Meter.
+ Added an Item Value Editor.
* Closing and re-opening a sub-menu will now display the starting page of that sub-menu.
* The player speed modifier now also applies to the player's walking speed.
* Clones now have a gps name as well.
* Disabling a character now disables this character's clones as well.
* Fixed a bug, that caused clones to not be deletable.

------------------------------------------------------------------------------

v1.6.1 (Game v1.3.2)
* Fixed a bug, that caused the entity gps to always be visible.

------------------------------------------------------------------------------

v1.6 (Game v1.3.2)
~ Introduction of a new menu-ui-system.
+ Added an exit-teleporter.
+ Added a character-speed modifier.
+ Added a character disabler/remover.
* Cloned characters can now be removed.
* The code has been optimized.
* The Mod Menu now shows each character's full name.

------------------------------------------------------------------------------

v1.5 (Game v1.3.2)
+ Added a character cloner.
+ Added the ability to never run out of items.
+ Added a running-speed multiplier.
* Renamed the "Item Manipulator" to "Item Cheater".
* Fixed a bug, that caused the Mod Menu to break the game every second start.

------------------------------------------------------------------------------

v1.4 (Game v1.3.2)
* Adjusted the teleporter for the ability to teleport each character to you.
* Adjusted the notebook-teleporter for the ability to teleport each notebook to you.

------------------------------------------------------------------------------

v1.3.1 (Game v1.3.2)
* Fixed a memory leak caused by the new UI

------------------------------------------------------------------------------

v1.3 (Game v1.3.2)
+ Added the ability to teleport to each character.
+ Added the ability to teleport to each notebook.
* Optimized the code used for the gps character names.
* Fixed an oversight, that caused the bully's gps text to appear in his belly.
* UI has been "re-designed".

------------------------------------------------------------------------------

v1.2 (Game v1.3.2)
+ Added the ability to manipulate your entire inventory.
* Fixed a bug, that caused the pause menu to not actually pause the game.

------------------------------------------------------------------------------

v1.1 (Game v1.3.1)
+ Added the ability to be ignored by 1st-Prize.
+ Added the ability to phase through solid matter.
* Fixed a bug, that allowed you to go through objects by using your new neck.
* Fixed a bug, that caused some NPCs to scream for no reason.
* Fixed a bug, that caused Gotta-Sweep to be overly attached.

------------------------------------------------------------------------------

v1.0 (Game v1.2.2)
+ Added the ability to be ignored by Baldi.
+ Added the ability to be ignored by the Bully.
+ Added the ability to be ignored by Playtime.
+ Added the ability to be ignored by Crafters.
+ Added the ability to be ignored by Gotta-Sweep.
+ Added the ability to be ignored by the Principal.
+ Added the the answer to life the universe and everything.
+ Added a neck to the player for up and down head-movement.
+ Added the ability to run forever.
+ Added a GPS-system.


################################## SCRIPTS ###################################
[ Symbol Hierarchy: ]
[ + Added           ]
[ * Edited          ]
[ - Removed         ]

+ ModMenuAdditional.cs
+ ModMenuBase.cs
* AlarmClockScript.cs
* BaldiScript.cs
* BsodaSparyScript.cs
* BullyScript.cs
* CraftersScript.cs
* CraftersTriggerScript.cs
* DetentionTextScript.cs
* FirstPrizeScript.cs
* GameControllerScript.cs
* JumpRopeScript.cs
* MathGameScript.cs
* NotebookScript.cs
* PlayerScript.cs
* PlaytimeScript
* PrincipalScript.cs
* StartButton.cs
* SweepScript.cs
* TapePlayerScript.cs