##############################################################################
##############################################################################
###              DISCLAIMER: I DID NOT MAKE THE ORIGINAL GAME              ###
###                 (AKA. BALDI'S BASICS - FIELD TRIP DEMO)                ###
###               THE ORIGINAL GAME WAS CREATED BY MYSTMAN12               ###
###                       (http://mystman12.itch.io)                       ###
##############################################################################
##############################################################################

Fasguy's Mod Menu v1.1.1 for Baldi's Basics - Field Trip Demo


################################# HOW TO USE #################################
### WINDOWS ###:
Windows Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to "Baldi's Basics Field Trip Demo_Data" -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).

### macOS/OS X ###:
macOS/OS X Video Tutorial: https://youtu.be/42aZEcvqHc8?t=3m20s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Copy the "Assembly-CSharp.dll" file.
2. Find your existing installation of the game.
3. Right-Click (or Control-Click) on the game (usually called BALDI).
4. Click "Show Package Contents".
5. Go to Contents -> Resources -> Data -> Managed
6. Paste the "Assembly-CSharp.dll" file into this Folder.
7. Replace the already existing file.
8. Start the game by Right-Clicking (or Control-Clicking) on the game and choosing "Open".
9. Press TAB in-game (to open the Mod Menu).

### LINUX ###:
Linux Video Tutorial: https://youtu.be/42aZEcvqHc8?t=5m35s
INFO: If you want to use the mod, then you need to have the original game already installed.
1. Find your existing installation of the game.
2. Go to "Baldi's Basics Field Trip Demo_Data" -> Managed
3. Extract the "Assembly-CSharp.dll" file into this Folder.
4. Replace the already existing file.
5. Start the game.
6. Press TAB in-game (to open the Mod Menu).


################################## CONTROLS ##################################
Mouse:				Viewpoint Movement
Left Click:			Use Door
Right Click:			Use Item
WASD or Up/Down/Left/Right:	Move
Alt + F4:			Close Game
TAB:				Open/Close Mod Menu


################################# CHANGELOG ##################################
v1.1.1
~ Updated ModMenuCore to v1.1
* The Teleporter-Menu now doesn't lockup the entire menu anymore.
* The Character-Menu now shows if there are no characters to edit in this scene.

------------------------------------------------------------------------------

v1.1
~ The Core Library has been rewritten.
+ Added a feature to stop the fire from burning out.
+ Added the ability to enable/disable It's a Bully.
+ Added the ability to enable/disable Cloudy Copter.
+ Added the ability to enable/disable Arts and Crafters.
+ Added the ability to be ignored by It's a Bully.
+ Added the ability to be ignored by Cloudy Copter.
+ Added the ability to be ignored by Arts and Crafters.
+ Added the ability to change It's a Bully's movement-speed.
+ Added the ability to change Cloudy Copter's movement-speed.
+ Added the ability to change Arts and Crafters's movement-speed.
+ Added the ability to clone It's a Bully.
+ Added the ability to clone Cloudy Copter.
+ Added the ability to clone Arts and Crafters.
+ Added the ability to teleport It's a Bully.
+ Added the ability to teleport Cloudy Copter.
+ Added the ability to teleport Arts and Crafters.
+ Added the ability to change It's a Bully's size.
+ Added the ability to change Cloudy Copter's size.
+ Added the ability to change Arts and Crafters's size.
+ Added the ability to make It's a Bully invisible.
+ Added the ability to make Cloudy Copter invisible.
* Fixed a bug, that prevented cameras from activating, after removing the currently active one.

------------------------------------------------------------------------------

v1.0
~ This version on par with v1.9.1 of the original Mod Menu, but with a few features removed.
+ Added the ability to enable/disable Baldi.
+ Added the ability to be ignored by Baldi.
+ Added the ability to change Baldi's movement-speed.
+ Added the ability to clone Baldi.
+ Added the ability to teleport Baldi.
+ Added the ability to change Baldi's size.
+ Added the ability to make Baldi invisible.
+ Added a neck to the player for up and down head-movement (3D-Camera movement).
+ Added the ability to run forever (Infinite Stamina).
+ Added a way to change your maximum Stamina value.
+ Added the ability to phase through solid matter (Noclip).
+ Added the ability to change your own speed.
+ Added a way to add cameras anywhere in the game (this will be part of a bigger project).
+ Added an Entity-GPS-system.
+ Added a Character Distance Meter.